<?php
/**
 * @version SVN: $Id: mod_#module#.php 147 2013-10-06 08:58:34Z michel $
 * @package    Iarcontact_form
 * @subpackage Base
 * @author     
 * @license    
 */

defined('_JEXEC') or die('Restricted access'); // no direct access

require_once __DIR__ . '/helper.php';
$item = modIarcontact_formHelper::getItem($params);
require(JModuleHelper::getLayoutPath('mod_iarcontact_form'));
require_once ('helper.php');

?>