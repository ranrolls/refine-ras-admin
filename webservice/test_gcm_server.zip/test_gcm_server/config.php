<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "rasmento_rasras");
define("DB_PASSWORD", "zzU5k]T!]R@w");
define("DB_DATABASE", "rasmento_ras");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyCmfaC2Wh2x3Iehv-aMGfoc3GlheKU-2j8"); // Place your Google API Key
?>