<?php 
/**
 * File name: $HeadURL: svn://tools.janguo.de/jacc/trunk/admin/templates/modules/tmpl/default.php $
 * Revision: $Revision: 147 $
 * Last modified: $Date: 2013-10-06 10:58:34 +0200 (So, 06. Okt 2013) $
 * Last modified by: $Author: michel $
 * @copyright	Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license 
 */
defined('_JEXEC') or die('Restricted access'); 
?>

<div class="home_page_slider<?php echo $params->get( 'moduleclass_sfx' ) ?>">


<script type="text/javascript">  
 
function reSizeWidth(){
	var winHeight= jQuery(window).height();
	var winWidth= jQuery(window).width();
	jQuery('.carousel').css({'width':winWidth,'height':winHeight});

}
jQuery(window).resize(function(){
	reSizeWidth();	
});


jQuery(function(){
 
 var PaginatioLenth;
 var Pagination;
 var thisNext;
 var thisPrev;
 var nextImg;
 var prevImg;
 var activeImg;
 var carouselWidth;
 var last = 500;
 var diff;
 var activePage = 0;
 var imglenth;
 var PaginationLi;
  reSizeWidth();
 jQuery('.carousel').each(function() {
  imglenth = jQuery(this).find('.img li').length;
  //jQuery(this).find('.img li').css({'left':jQuery(this).width()});
 // jQuery(this).find('.img li.active').css({'left':'0px'});
  Pagination = jQuery(this).find('.pagination ul');
  for(var i =0; i<imglenth; i++){
   jQuery(Pagination).append('<li></li>')
  }
  jQuery(Pagination).find('li:first').addClass('on');
  PaginationLi = jQuery(Pagination).find('li');
  PaginatioLenth = PaginationLi.length;
  jQuery(Pagination).parent().css({'width':15*PaginatioLenth});
  
  jQuery(this).find('.pagination li').click(function(event){
   //console.log('working ' + jQuery(this).index())
   var selectedPage = jQuery(this);
   selectPage(selectedPage);
  });
  
  jQuery(this).find('.rightArrow').click(function(event){
   thisNext = jQuery(this);
   diff = event.timeStamp - last;
   last = event.timeStamp;
   if(diff>500){
    nextAnimation();
   }
   
  });
  jQuery(this).find('.leftArrow').click(function(event){
   thisPrev = jQuery(this); 
   diff = event.timeStamp - last;
   last = event.timeStamp;
   if(diff>500){
    prevAnimation();
   }
   
  });
    });
 thisNext = jQuery('.carousel').find('.img li.active');
 var AutoRotate = setInterval (nextAnimation,10000);
 
 function nextAnimation(){
  carouselWidth = jQuery(thisNext).closest('.carousel').width();
  nextImg = jQuery(thisNext).closest('.carousel').find('.img li');
  activeImg = jQuery(thisNext).closest('.carousel').find('.img li.active');
  activePage++
  if(activePage>=nextImg.length){
   activePage=0
  }
  jQuery(activeImg).stop().fadeOut(500,function(){
   jQuery(this).removeClass('active');
   jQuery(this).next().addClass('active');
   thisPage = jQuery(thisNext);
   selesctPagination(activePage); 
  });
  if(jQuery(nextImg).last().hasClass('active')){
   //$(nextImg).first().css({left:carouselWidth});
   jQuery(nextImg).first().stop().fadeIn(500,function(){
    jQuery(nextImg).last().removeClass('active');
    jQuery(nextImg).first().addClass('active');
   });
   //console.log('working');
  }else{
   //jQuery(activeImg).next().css({left:carouselWidth});
   jQuery(activeImg).next().stop().fadeIn(500);
  }
 }
  
 function prevAnimation(){
  carouselWidth = jQuery(thisPrev).closest('.carousel').width();
  prevImg = jQuery(thisPrev).closest('.carousel').find('.img li');
  activeImg = jQuery(thisPrev).closest('.carousel').find('.img li.active');
  activePage--
  if(activePage<0){
   activePage=(prevImg.length)-1;
  }
  
  jQuery(activeImg).stop().fadeOut(500,function(){
   jQuery(this).removeClass('active');
   jQuery(this).prev().addClass('active'); 
   thisPage = jQuery(thisPrev);
   selesctPagination(activePage);
  });
  if(jQuery(prevImg).first().hasClass('active')){
   //jQuery(prevImg).last().css({left:-carouselWidth});
   jQuery(prevImg).last().stop().fadeIn(500,function(){
    jQuery(prevImg).first().removeClass('active');
    jQuery(prevImg).last().addClass('active');
   });
   //console.log('working');
  }else{
   //$(activeImg).prev().css({left:-carouselWidth});
   jQuery(activeImg).prev().stop().fadeIn(500);
  }
  
 }
  
});


function selesctPagination(activePage){
 var closecarousel = jQuery(thisPage).closest('.carousel');
 var carouselLenth = closecarousel.find('.img li').length;
 closecarousel.find('.pagination li').removeClass('on');
 closecarousel.find('.pagination li').eq(activePage).addClass('on');

 //console.log(activePage);
}

function selectPage(selectedPage){
 selectedPageIndex = selectedPage.index();
 mainCarouselWidth = jQuery(selectedPage).closest('.carousel').width();
 mainCarousel = jQuery(selectedPage).closest('.carousel').find('.img li');
 var alreadySalected = jQuery(selectedPage).parent().find('li.on').index();
 if(selectedPageIndex>alreadySalected){
  mainCarousel.eq(selectedPageIndex).stop().animate({left:0},500,function(){
  jQuery(this).removeClass('active');
   //$(this).next().addClass('active');
   //thisPage = $(thisNext);
   //selesctPagination(activePage); 
  });
 }
 
 //mainCarousel.eq(selectedPageIndex).hide();
 console.log(alreadySalected);

}
</script>


<style>
body{
 margin:0px;
 padding:0px;
}
ul{
 margin:0px;
 padding:0px;
}
li{
 list-style:none;
}
.carousel{
 margin:0 auto;
 width:100%;
 height:auto;
 position:relative;

 }
.carousel .img{
 overflow:hidden;
 width:inherit;
 height:inherit;
 position:relative;
}
.carousel .img li{
 width:inherit;
 position:absolute;
 height:inherit;
}
.carousel .arrow{
 position:absolute;
 width:40px;
 height:40px;
 top:40%;
 cursor:pointer;
 z-index:12;
}
.carousel .leftArrow{
 left:20px;
 background:url(http://www.rasmentorshipforum.com/images/prev.png) no-repeat;
}
.carousel .rightArrow{
 right:20px;
 background:url(http://www.rasmentorshipforum.com/images/next.png) no-repeat;
}
.carousel .pagination{
 margin:0 auto;
 height:10px;
 position:relative;
 z-index:12;
 bottom:20px;
}
.carousel .pagination li{
 width:10px;
 height:10px;
 background:url(http://72.41.212.225/Test/carousel/img/pagination.png) no-repeat;
 cursor:pointer;
 margin-right:5px;
 float:left;
}
.carousel .pagination li:hover, .carousel .pagination li.on{
 background:url(http://72.41.212.225/Test/carousel/img/pagination-on.png) no-repeat;
}
 
</style>
 
 <SCRIPT language="JavaScript"> 
  
 function openwindow() 
 { 
 window.open('http://www.rasmentorshipforum.com/discussion-forum/contest'); 
 } 
 
 </SCRIPT>


<div class="carousel">
 <div class="arrow leftArrow"></div>
 <div class="arrow rightArrow"></div>
 <ul class="img">
     <li><img src="http://www.rasmentorshipforum.com/images/ras-banner-1.png" width="100%" alt=""/> </li>

 <li class="active">
   
 <img style = "cursor:pointer;hand" src="http://www.rasmentorshipforum.com/images/ras-banner-1920.png" width="100%" alt="" onclick="javascript:openwindow()"/> </li>
     </ul>
    <!--<div class="pagination">
     <ul>
        </ul>
    </div>-->
</div>


</div>